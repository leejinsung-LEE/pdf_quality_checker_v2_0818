# gui/tabs/realtime_tab.py
"""
실시간 처리 탭 - Enhanced Edition (개선된 버전)
파일 처리 현황을 표시하는 메인 탭입니다.
2025.01 개선: 레이아웃 단순화, 열 숨기기, 폴더 필터 추가

개선사항:
1. 오른쪽 패널 제거 (드래그앤드롭은 사이드바로 이동)
2. 테이블 컬럼 재구성 및 열 숨기기 기능
3. 폴더별 필터링
4. 일괄 작업 기능
5. 향상된 키보드 단축키
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import customtkinter as ctk
from pathlib import Path
import threading
from datetime import datetime, timedelta
import shutil
import webbrowser
import os
import time
import json
import glob
import re

# 프로젝트 모듈
from config import Config
from pdf_analyzer import PDFAnalyzer
from report_generator import ReportGenerator
from theme_manager import get_theme_manager


class RealtimeTab:
    """실시간 처리 탭 클래스 - 개선된 버전"""
    
    # 상태 아이콘 정의
    STATUS_ICONS = {
        'waiting': '⏳',
        'processing': '⚙️',
        'success': '✅',
        'warning': '⚠️',
        'error': '❌'
    }
    
    def __init__(self, main_window, parent):
        """
        실시간 탭 초기화
        
        Args:
            main_window: 메인 윈도우 인스턴스
            parent: 부모 위젯 (Notebook)
        """
        self.main_window = main_window
        self.parent = parent
        
        # PDF 분석 결과를 저장할 딕셔너리
        self.pdf_results = {}
        
        # 처리 시간 추적용
        self.processing_times = {}
        self.timer_threads = {}
        
        # 필터 상태
        self.filter_status = tk.StringVar(value="all")
        self.search_var = tk.StringVar()
        self.folder_filter_var = tk.StringVar(value="all")
        
        # 열 표시 상태
        self.column_visibility = {
            'icon': True,
            'filename': True,  # 항상 표시
            'folder': True,
            'pagesize': True,
            'pages': True,
            'issues': True,
            'time': True,
            'report': True
        }
        
        # 선택된 항목들
        self.selected_items = set()
        
        # 툴팁 관리
        self.tooltips = {}
        
        # 테마 설정 로드
        self._load_theme_settings()
        
        # 탭 생성
        self._create_tab()
        
        # 단축키 바인딩
        self._bind_shortcuts()
        
        # 열 표시 설정 로드
        self._load_column_settings()
    
    def _load_theme_settings(self):
        """테마 설정 로드"""
        try:
            with open('user_settings.json', 'r', encoding='utf-8') as f:
                settings = json.load(f)
                self.current_theme = settings.get('theme', 'dark')
        except:
            self.current_theme = 'dark'
    
    def _load_column_settings(self):
        """열 표시 설정 로드"""
        try:
            with open('column_settings.json', 'r', encoding='utf-8') as f:
                self.column_visibility.update(json.load(f))
        except:
            pass
    
    def _save_column_settings(self):
        """열 표시 설정 저장"""
        try:
            with open('column_settings.json', 'w', encoding='utf-8') as f:
                json.dump(self.column_visibility, f)
        except:
            pass
    
    def _create_tab(self):
        """탭 생성"""
        self.tab = ctk.CTkFrame(self.parent, fg_color=self.main_window.colors['bg_primary'])
        self.parent.add(self.tab, text="🔄 실시간 처리")
        
        # 메인 컨테이너 (전체 영역 사용)
        main_container = ctk.CTkFrame(self.tab, fg_color="transparent")
        main_container.pack(fill='both', expand=True, padx=20, pady=20)
        
        # 헤더
        self._create_header(main_container)
        
        # 필터 바
        self._create_filter_bar(main_container)
        
        # 일괄 작업 바
        self._create_batch_actions_bar(main_container)
        
        # 메인 테이블
        self._create_main_table(main_container)
        
        # 컨텍스트 메뉴
        self._create_context_menus()
    
    def _create_header(self, parent):
        """헤더 생성"""
        header_frame = ctk.CTkFrame(parent, fg_color="transparent")
        header_frame.pack(fill='x', pady=(0, 15))
        
        # 왼쪽: 제목
        title_frame = ctk.CTkFrame(header_frame, fg_color="transparent")
        title_frame.pack(side='left', fill='x', expand=True)
        
        ctk.CTkLabel(
            title_frame,
            text="실시간 처리 현황",
            font=self.main_window.fonts['heading']
        ).pack(side='left')
        
        ctk.CTkLabel(
            title_frame,
            text="모든 처리 이력 포함",
            font=self.main_window.fonts['small'],
            text_color=self.main_window.colors['text_secondary']
        ).pack(side='left', padx=(10, 0))
        
        # 오른쪽: 버튼들
        btn_frame = ctk.CTkFrame(header_frame, fg_color="transparent")
        btn_frame.pack(side='right')
        
        # 테마 토글
        self.theme_btn = ctk.CTkButton(
            btn_frame,
            text="🌙" if self.current_theme == 'dark' else "☀️",
            command=self.toggle_theme,
            width=40,
            height=32,
            fg_color=self.main_window.colors['bg_card']
        )
        self.theme_btn.pack(side='left', padx=(0, 5))
        
        # 파일 추가 버튼
        add_file_btn = ctk.CTkButton(
            btn_frame,
            text="📁 파일 추가",
            command=self.browse_files,
            width=100,
            height=32,
            fg_color=self.main_window.colors['accent']
        )
        add_file_btn.pack(side='left', padx=(0, 5))
        
        # 새로고침 버튼
        refresh_btn = ctk.CTkButton(
            btn_frame,
            text="🔄 새로고침",
            command=self.refresh,
            width=100,
            height=32,
            fg_color=self.main_window.colors['bg_card'],
            hover_color=self.main_window.colors['accent']
        )
        refresh_btn.pack(side='left')
    
    def _create_filter_bar(self, parent):
        """필터 바 생성"""
        filter_frame = ctk.CTkFrame(
            parent,
            fg_color=self.main_window.colors['bg_card'],
            corner_radius=10,
            height=50
        )
        filter_frame.pack(fill='x', pady=(0, 10))
        filter_frame.pack_propagate(False)
        
        inner_frame = ctk.CTkFrame(filter_frame, fg_color="transparent")
        inner_frame.pack(fill='both', expand=True, padx=15, pady=10)
        
        # 상태 필터 버튼들
        filter_left = ctk.CTkFrame(inner_frame, fg_color="transparent")
        filter_left.pack(side='left', fill='y')
        
        ctk.CTkLabel(filter_left, text="필터:", font=self.main_window.fonts['body']).pack(side='left', padx=(0, 10))
        
        filters = [
            ("전체", "all", None),
            ("완료", "success", self.main_window.colors['success']),
            ("경고", "warning", self.main_window.colors['warning']),
            ("오류", "error", self.main_window.colors['error']),
            ("처리중", "processing", self.main_window.colors['accent']),
            ("문제있음⚠️", "has_issues", self.main_window.colors['warning'])
        ]
        
        self.filter_buttons = {}
        for text, value, color in filters:
            btn = ctk.CTkButton(
                filter_left,
                text=text,
                command=lambda v=value: self.apply_filter(v),
                width=70,
                height=28,
                fg_color=color if color else self.main_window.colors['bg_secondary'],
                hover_color=self.main_window.colors['accent'] if not color else color
            )
            btn.pack(side='left', padx=2)
            self.filter_buttons[value] = btn
        
        # 폴더 필터
        folder_filter_frame = ctk.CTkFrame(inner_frame, fg_color="transparent")
        folder_filter_frame.pack(side='left', padx=(20, 0))
        
        ctk.CTkLabel(folder_filter_frame, text="폴더:", font=self.main_window.fonts['body']).pack(side='left', padx=(0, 10))
        
        # 폴더 목록 가져오기
        folder_values = ["전체 표시"] + [f['name'] for f in self.main_window.folder_watcher.get_folder_list()]
        folder_values.append("드래그앤드롭")
        
        self.folder_combo = ttk.Combobox(
            folder_filter_frame,
            textvariable=self.folder_filter_var,
            values=folder_values,
            state='readonly',
            width=20
        )
        self.folder_combo.pack(side='left')
        self.folder_combo.bind('<<ComboboxSelected>>', lambda e: self.apply_folder_filter())
        
        # 검색창
        search_frame = ctk.CTkFrame(inner_frame, fg_color="transparent")
        search_frame.pack(side='right', fill='y')
        
        ctk.CTkLabel(search_frame, text="🔍", font=('Arial', 16)).pack(side='left', padx=(10, 5))
        
        search_entry = ctk.CTkEntry(
            search_frame,
            placeholder_text="파일명 검색...",
            textvariable=self.search_var,
            width=200,
            height=28
        )
        search_entry.pack(side='left')
        search_entry.bind('<KeyRelease>', lambda e: self.apply_search())
    
    def _create_batch_actions_bar(self, parent):
        """일괄 작업 바 생성"""
        batch_frame = ctk.CTkFrame(parent, fg_color="transparent", height=30)
        batch_frame.pack(fill='x', pady=(0, 5))
        batch_frame.pack_propagate(False)
        
        # 전체 선택
        self.select_all_var = tk.BooleanVar()
        self.select_all_check = ctk.CTkCheckBox(
            batch_frame,
            text="전체선택",
            variable=self.select_all_var,
            command=self.toggle_select_all,
            font=self.main_window.fonts['body']
        )
        self.select_all_check.pack(side='left')
        
        # 선택 개수 표시
        self.selection_label = ctk.CTkLabel(
            batch_frame,
            text="선택: 0개",
            font=self.main_window.fonts['small'],
            text_color=self.main_window.colors['text_secondary']
        )
        self.selection_label.pack(side='left', padx=20)
        
        # 일괄 작업 버튼들
        batch_btn_frame = ctk.CTkFrame(batch_frame, fg_color="transparent")
        batch_btn_frame.pack(side='left', padx=20)
        
        ctk.CTkButton(
            batch_btn_frame,
            text="재처리",
            command=self.batch_reprocess,
            width=70,
            height=26,
            fg_color=self.main_window.colors['bg_secondary']
        ).pack(side='left', padx=2)
        
        ctk.CTkButton(
            batch_btn_frame,
            text="삭제",
            command=self.batch_delete,
            width=70,
            height=26,
            fg_color=self.main_window.colors['bg_secondary'],
            hover_color=self.main_window.colors['error']
        ).pack(side='left', padx=2)
        
        ctk.CTkButton(
            batch_btn_frame,
            text="보고서 일괄생성",
            command=self.batch_generate_reports,
            width=120,
            height=26,
            fg_color=self.main_window.colors['bg_secondary']
        ).pack(side='left', padx=2)
    
    def _create_main_table(self, parent):
        """메인 테이블 생성"""
        # 테이블 프레임
        table_frame = ctk.CTkFrame(
            parent,
            fg_color=self.main_window.colors['bg_card'],
            corner_radius=10
        )
        table_frame.pack(fill='both', expand=True)
        
        # 트리뷰 프레임
        tree_frame = ctk.CTkFrame(table_frame, fg_color="transparent")
        tree_frame.pack(fill='both', expand=True, padx=15, pady=15)
        
        # 컬럼 정의
        columns = ('icon', 'filename', 'folder', 'pagesize', 'pages', 'issues', 'time', 'report')
        self.realtime_tree = ttk.Treeview(
            tree_frame,
            columns=columns,
            show='tree headings',
            height=20
        )
        
        # 컬럼 헤더 설정
        self.realtime_tree.heading('#0', text='☐', anchor='center')  # 체크박스 컬럼
        self.realtime_tree.heading('icon', text='')
        self.realtime_tree.heading('filename', text='파일명')
        self.realtime_tree.heading('folder', text='폴더')
        self.realtime_tree.heading('pagesize', text='페이지크기')
        self.realtime_tree.heading('pages', text='페이지')
        self.realtime_tree.heading('issues', text='문제')
        self.realtime_tree.heading('time', text='시간')
        self.realtime_tree.heading('report', text='보고서')
        
        # 컬럼 너비
        self.realtime_tree.column('#0', width=30, stretch=False)
        self.realtime_tree.column('icon', width=30, stretch=False)
        self.realtime_tree.column('filename', width=300)
        self.realtime_tree.column('folder', width=120)
        self.realtime_tree.column('pagesize', width=120)
        self.realtime_tree.column('pages', width=60)
        self.realtime_tree.column('issues', width=80)
        self.realtime_tree.column('time', width=150)
        self.realtime_tree.column('report', width=60, stretch=False)
        
        # 초기 열 표시 상태 적용
        self._apply_column_visibility()
        
        # 스크롤바
        v_scrollbar = ttk.Scrollbar(tree_frame, orient='vertical', command=self.realtime_tree.yview)
        h_scrollbar = ttk.Scrollbar(tree_frame, orient='horizontal', command=self.realtime_tree.xview)
        self.realtime_tree.configure(yscrollcommand=v_scrollbar.set, xscrollcommand=h_scrollbar.set)
        
        # 배치
        self.realtime_tree.grid(row=0, column=0, sticky='nsew')
        v_scrollbar.grid(row=0, column=1, sticky='ns')
        h_scrollbar.grid(row=1, column=0, sticky='ew')
        
        tree_frame.grid_rowconfigure(0, weight=1)
        tree_frame.grid_columnconfigure(0, weight=1)
        
        # 태그 색상
        self.realtime_tree.tag_configure('processing', foreground=self.main_window.colors['accent'])
        self.realtime_tree.tag_configure('success', foreground=self.main_window.colors['success'])
        self.realtime_tree.tag_configure('error', foreground=self.main_window.colors['error'])
        self.realtime_tree.tag_configure('warning', foreground=self.main_window.colors['warning'])
        
        # 이벤트 바인딩
        self.realtime_tree.bind('<Button-1>', self._on_tree_click)
        self.realtime_tree.bind('<Button-3>', self._show_context_menu)
        self.realtime_tree.bind('<Double-Button-1>', self._on_double_click)
    
    def _create_context_menus(self):
        """컨텍스트 메뉴들 생성"""
        # 헤더 우클릭 메뉴 (열 숨기기)
        self.header_menu = tk.Menu(
            self.main_window.root,
            tearoff=0,
            bg=self.main_window.colors['bg_secondary'],
            fg=self.main_window.colors['text_primary']
        )
        
        # 열 표시 옵션
        columns = [
            ('icon', '상태 아이콘'),
            ('folder', '폴더'),
            ('pagesize', '페이지크기'),
            ('pages', '페이지'),
            ('issues', '문제'),
            ('time', '시간'),
            ('report', '보고서')
        ]
        
        for col_id, col_name in columns:
            var = tk.BooleanVar(value=self.column_visibility.get(col_id, True))
            self.header_menu.add_checkbutton(
                label=f"☑ {col_name}",
                variable=var,
                command=lambda c=col_id, v=var: self.toggle_column(c, v.get())
            )
        
        self.header_menu.add_separator()
        self.header_menu.add_command(label="모든 열 표시", command=self.show_all_columns)
        self.header_menu.add_command(label="기본값 복원", command=self.reset_columns)
        
        # 헤더 클릭 이벤트
        self.realtime_tree.bind('<Button-3>', self._on_header_right_click, add='+')
        
        # 아이템 우클릭 메뉴
        self.context_menu = tk.Menu(
            self.main_window.root,
            tearoff=0,
            bg=self.main_window.colors['bg_secondary'],
            fg=self.main_window.colors['text_primary']
        )
        
        self.context_menu.add_command(label="📄 보고서 보기", command=self._view_report)
        self.context_menu.add_command(label="📁 폴더에서 보기", command=self._show_in_folder)
        self.context_menu.add_separator()
        self.context_menu.add_command(label="🔄 다시 처리", command=self._reprocess_file)
        self.context_menu.add_command(label="❌ 목록에서 제거", command=self._delete_selected)
    
    def _bind_shortcuts(self):
        """단축키 바인딩"""
        # 기존 단축키
        self.main_window.root.bind('<F5>', lambda e: self.refresh())
        self.main_window.root.bind('<Control-o>', lambda e: self.browse_files())
        self.main_window.root.bind('<Control-d>', lambda e: self.main_window.add_watch_folder())
        self.main_window.root.bind('<Control-r>', lambda e: self._reprocess_file())
        self.realtime_tree.bind('<Delete>', lambda e: self._delete_selected())
        
        # 추가 단축키
        self.realtime_tree.bind('<space>', lambda e: self._toggle_item_selection())
        self.main_window.root.bind('<Control-a>', lambda e: self.select_all())
        self.main_window.root.bind('<Control-h>', lambda e: self._show_column_menu())
    
    def _apply_column_visibility(self):
        """열 표시 상태 적용"""
        for col_id, visible in self.column_visibility.items():
            if col_id != 'filename':  # 파일명은 항상 표시
                if visible:
                    self.realtime_tree.heading(col_id, text=self._get_column_text(col_id))
                    self.realtime_tree.column(col_id, width=self._get_column_width(col_id))
                else:
                    self.realtime_tree.column(col_id, width=0, stretch=False)
    
    def _get_column_text(self, col_id):
        """컬럼 텍스트 반환"""
        texts = {
            'icon': '',
            'folder': '폴더',
            'pagesize': '페이지크기',
            'pages': '페이지',
            'issues': '문제',
            'time': '시간',
            'report': '보고서'
        }
        return texts.get(col_id, '')
    
    def _get_column_width(self, col_id):
        """컬럼 기본 너비 반환"""
        widths = {
            'icon': 30,
            'folder': 120,
            'pagesize': 120,
            'pages': 60,
            'issues': 80,
            'time': 150,
            'report': 60
        }
        return widths.get(col_id, 100)
    
    def toggle_column(self, col_id, visible):
        """열 표시/숨김 토글"""
        self.column_visibility[col_id] = visible
        self._apply_column_visibility()
        self._save_column_settings()
    
    def show_all_columns(self):
        """모든 열 표시"""
        for col_id in self.column_visibility:
            self.column_visibility[col_id] = True
        self._apply_column_visibility()
        self._save_column_settings()
    
    def reset_columns(self):
        """열 설정 초기화"""
        self.column_visibility = {
            'icon': True,
            'filename': True,
            'folder': True,
            'pagesize': True,
            'pages': True,
            'issues': True,
            'time': True,
            'report': True
        }
        self._apply_column_visibility()
        self._save_column_settings()
    
    def _on_header_right_click(self, event):
        """헤더 우클릭 이벤트"""
        region = self.realtime_tree.identify_region(event.x, event.y)
        if region == "heading":
            self.header_menu.post(event.x_root, event.y_root)
    
    def _show_column_menu(self):
        """열 메뉴 표시 (Ctrl+H)"""
        x = self.main_window.root.winfo_pointerx()
        y = self.main_window.root.winfo_pointery()
        self.header_menu.post(x, y)
    
    def add_file_to_process(self, file_path: Path, folder_config: dict):
        """폴더에서 발견된 파일 추가 (기존 메서드 유지)"""
        self.main_window.logger.log(f"PDF 발견: {file_path.name} (폴더: {file_path.parent.name})")
        
        # 안전한 item ID 생성
        item_id = self.main_window._generate_safe_item_id("folder")
        
        # 처리 시작 시간 기록
        self.processing_times[item_id] = {
            'start': time.time(),
            'status': 'waiting'
        }
        
        # 시간 포맷
        current_time = datetime.now().strftime('%H:%M:%S')
        
        # 실시간 탭에 추가
        self.realtime_tree.insert(
            '',
            'end',
            iid=item_id,
            text='☐',  # 체크박스
            values=(
                self.STATUS_ICONS['waiting'],  # 아이콘
                file_path.name,  # 파일명
                file_path.parent.name,  # 폴더
                '-',  # 페이지크기
                '-',  # 페이지수
                '-',  # 문제
                f"대기 중 ({current_time})",  # 시간
                ''   # 보고서
            ),
            tags=('processing',)
        )
        
        # 처리 시작
        self._process_pdf_file(file_path, folder_config, item_id)
    
    def _on_tree_click(self, event):
        """트리 클릭 이벤트"""
        region = self.realtime_tree.identify_region(event.x, event.y)
        if region == 'tree':
            item = self.realtime_tree.identify_row(event.y)
            if item:
                # 체크박스 토글
                self._toggle_item_selection_by_id(item)
            return 'break'
        elif region == 'cell':
            col = self.realtime_tree.identify_column(event.x)
            if col == '#8':  # 보고서 컬럼
                item = self.realtime_tree.identify_row(event.y)
                if item:
                    self._view_report_by_id(item)
    
    def _toggle_item_selection_by_id(self, item_id):
        """아이템 선택 토글"""
        if item_id in self.selected_items:
            self.selected_items.remove(item_id)
            self.realtime_tree.item(item_id, text='☐')
        else:
            self.selected_items.add(item_id)
            self.realtime_tree.item(item_id, text='☑')
        
        self._update_selection_count()
    
    def _toggle_item_selection(self):
        """현재 선택된 아이템 토글 (Space)"""
        selection = self.realtime_tree.selection()
        for item in selection:
            self._toggle_item_selection_by_id(item)
    
    def _update_selection_count(self):
        """선택 개수 업데이트"""
        count = len(self.selected_items)
        self.selection_label.configure(text=f"선택: {count}개")
        
        # 전체선택 체크박스 상태 업데이트
        total_items = len(self.realtime_tree.get_children())
        if count == 0:
            self.select_all_var.set(False)
        elif count == total_items and total_items > 0:
            self.select_all_var.set(True)
        else:
            self.select_all_var.set(False)
    
    def toggle_select_all(self):
        """전체 선택/해제"""
        if self.select_all_var.get():
            self.select_all()
        else:
            self.deselect_all()
    
    def select_all(self):
        """모두 선택"""
        self.selected_items.clear()
        for item in self.realtime_tree.get_children():
            self.selected_items.add(item)
            self.realtime_tree.item(item, text='☑')
        self._update_selection_count()
    
    def deselect_all(self):
        """모두 선택 해제"""
        for item in self.selected_items:
            self.realtime_tree.item(item, text='☐')
        self.selected_items.clear()
        self._update_selection_count()
    
    def batch_reprocess(self):
        """일괄 재처리"""
        if not self.selected_items:
            messagebox.showinfo("정보", "재처리할 파일을 선택하세요.")
            return
        
        if messagebox.askyesno("확인", f"{len(self.selected_items)}개 파일을 재처리하시겠습니까?"):
            messagebox.showinfo("정보", "일괄 재처리 기능은 개발 중입니다.")
    
    def batch_delete(self):
        """일괄 삭제"""
        if not self.selected_items:
            messagebox.showinfo("정보", "삭제할 항목을 선택하세요.")
            return
        
        if messagebox.askyesno("확인", f"{len(self.selected_items)}개 항목을 목록에서 제거하시겠습니까?"):
            for item in list(self.selected_items):
                # 타이머 정리
                if item in self.processing_times:
                    del self.processing_times[item]
                if item in self.timer_threads:
                    del self.timer_threads[item]
                
                # PDF 결과 정리 (추가)
                if item in self.pdf_results:
                    del self.pdf_results[item]
                
                self.realtime_tree.delete(item)
            
            self.selected_items.clear()
            self._update_selection_count()
    
    def batch_generate_reports(self):
        """일괄 보고서 생성"""
        if not self.selected_items:
            messagebox.showinfo("정보", "보고서를 생성할 파일을 선택하세요.")
            return
        
        messagebox.showinfo("정보", "일괄 보고서 생성 기능은 개발 중입니다.")
    
    def apply_filter(self, status):
        """상태별 필터 적용"""
        self.filter_status.set(status)
        
        # 버튼 스타일 업데이트
        for key, btn in self.filter_buttons.items():
            if key == status:
                btn.configure(fg_color=self.main_window.colors['accent'])
            else:
                # 원래 색상 복원
                original_color = None
                for text, value, color in [
                    ("전체", "all", None),
                    ("완료", "success", self.main_window.colors['success']),
                    ("경고", "warning", self.main_window.colors['warning']),
                    ("오류", "error", self.main_window.colors['error']),
                    ("처리중", "processing", self.main_window.colors['accent']),
                    ("문제있음⚠️", "has_issues", self.main_window.colors['warning'])
                ]:
                    if value == key:
                        original_color = color if color else self.main_window.colors['bg_secondary']
                        break
                btn.configure(fg_color=original_color)
        
        self._update_tree_view()
    
    def apply_folder_filter(self):
        """폴더 필터 적용"""
        folder = self.folder_filter_var.get()
        if folder == "전체 표시":
            self.folder_filter_var.set("all")
        self._update_tree_view()
    
    def apply_search(self):
        """검색 필터 적용"""
        self._update_tree_view()
    
    def _update_tree_view(self):
        """트리뷰 업데이트 (필터링 적용)"""
        # 모든 항목 가져오기
        all_items = self.realtime_tree.get_children()
        
        # 검색어
        search_text = self.search_var.get().lower()
        
        # 필터 상태
        filter_status = self.filter_status.get()
        folder_filter = self.folder_filter_var.get()
        
        for item_id in all_items:
            item = self.realtime_tree.item(item_id)
            values = item['values']
            filename = values[1].lower()  # 파일명
            folder = values[2]  # 폴더
            tags = item['tags']
            
            # 검색어 체크
            show = True
            if search_text and search_text not in filename:
                show = False
            
            # 상태 필터 체크
            if show and filter_status != "all":
                if filter_status == "has_issues":
                    # 문제있음 필터: 경고 또는 오류
                    if 'warning' not in tags and 'error' not in tags:
                        show = False
                elif filter_status not in tags:
                    show = False
            
            # 폴더 필터 체크
            if show and folder_filter != "all" and folder_filter != "전체 표시":
                if folder != folder_filter:
                    show = False
            
            # 표시/숨김
            if show:
                self.realtime_tree.reattach(item_id, '', 'end')
            else:
                self.realtime_tree.detach(item_id)
    
    def browse_files(self):
        """파일 선택"""
        files = filedialog.askopenfilenames(
            title="PDF 파일 선택",
            filetypes=[("PDF 파일", "*.pdf"), ("모든 파일", "*.*")]
        )
        
        if files:
            messagebox.showinfo("정보", "파일은 사이드바의 드래그앤드롭 영역에서 처리하세요.")
    
    def refresh(self):
        """새로고침 (F5)"""
        # 필터 초기화
        self.filter_status.set("all")
        self.search_var.set("")
        self.folder_filter_var.set("all")
        self.apply_filter("all")
        
        # 선택 초기화
        self.deselect_all()
        
        self.main_window.statusbar.set_status("실시간 현황이 새로고침되었습니다.")
    
    def toggle_theme(self):
        """테마 전환"""
        theme_manager = get_theme_manager()
        new_theme = theme_manager.toggle_theme()
        
        if new_theme == 'light':
            self.theme_btn.configure(text="☀️")
        else:
            self.theme_btn.configure(text="🌙")
        
        self.current_theme = new_theme
        
        messagebox.showinfo("테마 변경", f"{new_theme.title()} 모드로 변경되었습니다.\n완전히 적용하려면 프로그램을 재시작하세요.")
    
    def _sanitize_filename(self, filename):
        """파일명에서 특수문자를 안전한 문자로 변경"""
        # 특수문자를 언더스코어로 변경
        sanitized = re.sub(r'[<>:"/\\|?*\[\]]', '_', filename)
        # 연속된 언더스코어를 하나로 변경
        sanitized = re.sub(r'_+', '_', sanitized)
        # 앞뒤 언더스코어 제거
        sanitized = sanitized.strip('_')
        return sanitized
    
    def _format_file_size(self, size_bytes):
        """파일 크기를 읽기 쉬운 형식으로 변환"""
        for unit in ['B', 'KB', 'MB', 'GB']:
            if size_bytes < 1024.0:
                return f"{size_bytes:.1f} {unit}"
            size_bytes /= 1024.0
        return f"{size_bytes:.1f} TB"
    
    def _get_page_size_info(self, pages_info):
        """페이지 크기 정보 분석"""
        if not pages_info:
            return "알 수 없음"
        
        # 모든 페이지의 크기 수집
        size_map = {}
        for page in pages_info:
            size_key = page['paper_size']
            if size_key not in size_map:
                size_map[size_key] = {
                    'count': 0,
                    'size_str': page['size_formatted'],
                    'pages': []
                }
            size_map[size_key]['count'] += 1
            size_map[size_key]['pages'].append(page['page_number'])
        
        # 결과 포맷팅
        if len(size_map) == 1:
            # 모든 페이지가 같은 크기
            paper_size = list(size_map.keys())[0]
            size_info = list(size_map.values())[0]
            return f"{paper_size} ({size_info['size_str']})"
        else:
            # 여러 크기 혼합
            sizes = []
            for paper_size, info in size_map.items():
                sizes.append(f"{paper_size}({info['count']}p)")
            return f"혼합: {', '.join(sizes[:3])}"
    
    def _start_processing_timer(self, item_id):
        """처리 시간 타이머 시작"""
        def update_timer():
            while item_id in self.processing_times and self.processing_times[item_id]['status'] == 'processing':
                elapsed = time.time() - self.processing_times[item_id]['start']
                elapsed_str = f"{int(elapsed)}초"
                
                try:
                    values = list(self.realtime_tree.item(item_id)['values'])
                    values[6] = f"처리 중... ({elapsed_str})"
                    self.realtime_tree.item(item_id, values=values)
                except:
                    break
                
                time.sleep(1)
        
        timer_thread = threading.Thread(target=update_timer, daemon=True)
        timer_thread.start()
        self.timer_threads[item_id] = timer_thread
    
    def _process_pdf_file(self, file_path: Path, folder_config: dict, tree_item_id: str):
        """PDF 파일 처리 (기존 로직 유지)"""
        def process():
            try:
                # 처리 상태 업데이트
                self.processing_times[tree_item_id]['status'] = 'processing'
                self._start_processing_timer(tree_item_id)
                
                # 상태 업데이트: 처리 중
                values = list(self.realtime_tree.item(tree_item_id)['values'])
                values[0] = self.STATUS_ICONS['processing']
                values[6] = "처리 중... (0초)"
                self.realtime_tree.item(tree_item_id, values=values)
                
                # 잉크량 분석 옵션 확인
                include_ink = folder_config.get('auto_fix_settings', {}).get(
                    'include_ink_analysis',
                    Config.is_ink_analysis_enabled()
                )
                
                # PDF 분석
                analyzer = PDFAnalyzer()
                result = analyzer.analyze(
                    str(file_path),
                    include_ink_analysis=include_ink,
                    preflight_profile=folder_config.get('profile', 'offset')
                )
                
                # 분석 결과 저장
                self.pdf_results[tree_item_id] = result
                
                # 데이터베이스에 저장
                try:
                    self.main_window.data_manager.save_analysis_result(result)
                    self.main_window.logger.log(f"데이터베이스 저장 완료: {file_path.name}")
                except Exception as e:
                    self.main_window.logger.error(f"데이터베이스 저장 실패: {e}")
                
                # 드래그앤드롭과 폴더 감시 구분
                is_folder_watch = folder_config.get('path') is not None
                
                # 리포트 저장 경로 결정
                output_base = file_path.parent
                reports_folder = output_base / 'reports'
                reports_folder.mkdir(exist_ok=True)
                
                if not is_folder_watch:
                    self.main_window.logger.log(f"드래그앤드롭 리포트 폴더 생성: {reports_folder}")
                
                # 보고서 생성
                generator = ReportGenerator()
                # 안전한 파일명 생성 (특수문자 처리)
                safe_filename = self._sanitize_filename(file_path.stem)
                report_filename = f"{safe_filename}_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
                
                # 텍스트 보고서 저장
                text_path = generator.save_text_report(
                    result,
                    output_path=reports_folder / f"{report_filename}.txt"
                )
                
                # HTML 보고서 저장
                html_path = generator.save_html_report(
                    result,
                    output_path=reports_folder / f"{report_filename}.html"
                )
                
                self.main_window.logger.log(f"리포트 생성 완료: {reports_folder}")
                
                # 결과에 따라 상태 결정
                issues = result.get('issues', [])
                error_count = sum(1 for i in issues if i['severity'] == 'error')
                warning_count = sum(1 for i in issues if i['severity'] == 'warning')
                
                # 페이지수와 파일 크기 추출
                page_count = result.get('basic_info', {}).get('page_count', 0)
                file_size = result.get('file_size', 0)
                file_size_formatted = result.get('file_size_formatted', '-')
                
                # 페이지 크기 정보
                pages_info = result.get('pages', [])
                page_size_info = self._get_page_size_info(pages_info)
                
                # 처리 소요 시간 계산
                processing_time = time.time() - self.processing_times[tree_item_id]['start']
                processing_time_str = f"{processing_time:.1f}초"
                
                # 자동 수정 처리
                auto_fix_applied = False
                auto_fix_success = False
                fixed_file_path = None
                
                if folder_config.get('auto_fix_settings', {}).get('auto_convert_rgb', False) or \
                   folder_config.get('auto_fix_settings', {}).get('auto_outline_fonts', False):
                    
                    try:
                        # PDF 수정기 import
                        from pdf_fixer import PDFFixer
                        
                        fixer = PDFFixer(settings=folder_config.get('auto_fix_settings', {}))
                        fix_result = fixer.fix_pdf(file_path, result)
                        
                        if fix_result and fix_result.get('fixed') and fix_result.get('modifications'):
                            auto_fix_applied = True
                            auto_fix_success = True
                            fixed_file_path = Path(fix_result['fixed'])
                            
                            self.main_window.logger.log(
                                f"자동 수정 완료: {', '.join(fix_result['modifications'])}"
                            )
                            
                            # 알림 발송
                            if hasattr(self.main_window, 'notification_manager'):
                                self.main_window.notification_manager.notify_auto_fix_success(
                                    file_path.name,
                                    fix_result['modifications']
                                )
                    
                    except Exception as e:
                        self.main_window.logger.error(f"자동 수정 실패: {e}")
                        auto_fix_applied = True
                        auto_fix_success = False
                
                # 자동 수정된 파일 처리
                if auto_fix_success and fixed_file_path and fixed_file_path.exists():
                    # Copy auto-fixed file to completed folder
                    completed_folder = Config.OUTPUT_PATH / Config.COMPLETED_FOLDER
                    completed_folder.mkdir(exist_ok=True, parents=True)
                    
                    try:
                        # Copy the fixed file (not move)
                        dest_path = completed_folder / fixed_file_path.name
                        shutil.copy2(str(fixed_file_path), str(dest_path))
                        
                        # Delete the temporary file
                        fixed_file_path.unlink()
                        
                        self.main_window.logger.log(
                            f"자동 수정 파일 생성: {dest_path.name} (원본 유지)"
                        )
                        
                        # Set status for UI
                        status = 'success'
                        status_text = '자동수정 완료'
                        icon = self.STATUS_ICONS['success']
                        
                    except Exception as e:
                        self.main_window.logger.error(f"파일 복사 실패: {e}")
                        status = 'error'
                        status_text = '복사 실패'
                        icon = self.STATUS_ICONS['error']
                else:
                    # 일반 처리 완료
                    if error_count > 0:
                        status = 'error'
                        status_text = '오류'
                        icon = self.STATUS_ICONS['error']
                    elif warning_count > 0:
                        status = 'warning'
                        status_text = '경고'
                        icon = self.STATUS_ICONS['warning']
                    else:
                        status = 'success'
                        status_text = '완료'
                        icon = self.STATUS_ICONS['success']
                
                # 완료 시간
                complete_time = datetime.now().strftime('%H:%M:%S')
                
                # 처리 상태 업데이트
                self.processing_times[tree_item_id]['status'] = 'completed'
                
                # UI 업데이트
                self.realtime_tree.item(
                    tree_item_id,
                    values=(
                        icon,  # 아이콘
                        file_path.name,  # 파일명
                        file_path.parent.name,  # 폴더
                        page_size_info,  # 페이지크기
                        f"{page_count}p",  # 페이지
                        f"오류:{error_count} 경고:{warning_count}",  # 문제
                        f"{status_text} ({complete_time}, {processing_time_str})",  # 시간
                        "📄"  # 보고서
                    ),
                    tags=(status,)
                )
                
                # 알림
                self.main_window.notification_manager.notify_success(
                    file_path.name,
                    len(issues),
                    page_count=page_count,
                    processing_time=processing_time
                )
                
            except Exception as e:
                self.main_window.logger.error(f"처리 오류: {e}")
                error_time = datetime.now().strftime('%H:%M:%S')
                
                # 처리 상태 업데이트
                if tree_item_id in self.processing_times:
                    self.processing_times[tree_item_id]['status'] = 'error'
                
                # 오류 UI 업데이트
                values = list(self.realtime_tree.item(tree_item_id)['values'])
                values[0] = self.STATUS_ICONS['error']
                values[6] = f"오류 ({error_time}) - 원본 유지"
                values[5] = str(e)[:50]
                self.realtime_tree.item(tree_item_id, values=values, tags=('error',))
                
                # 오류 알림
                self.main_window.notification_manager.notify_error(file_path.name, str(e))
        
        # 별도 스레드에서 처리
        thread = threading.Thread(target=process, daemon=True)
        thread.start()
    
    def _show_context_menu(self, event):
        """우클릭 메뉴 표시"""
        item = self.realtime_tree.identify_row(event.y)
        if item:
            self.realtime_tree.selection_set(item)
            self.context_menu.post(event.x_root, event.y_root)
    
    def _on_double_click(self, event):
        """더블클릭 이벤트"""
        selection = self.realtime_tree.selection()
        if selection:
            self._view_report()
    
    def _view_report(self):
        """보고서 보기"""
        selection = self.realtime_tree.selection()
        if not selection:
            return
        
        self._view_report_by_id(selection[0])
    
    def _view_report_by_id(self, item_id):
        """ID로 보고서 보기 - 특수문자 파일명 처리 개선"""
        item = self.realtime_tree.item(item_id)
        filename = item['values'][1]  # 파일명
        folder_name = item['values'][2]  # 폴더
        
        # PDF 분석 결과에서 원본 파일 경로 가져오기
        if item_id in self.pdf_results:
            pdf_result = self.pdf_results[item_id]
            file_path = pdf_result.get('file_path')
            
            if file_path:
                # 원본 파일이 있는 폴더의 reports 하위 폴더
                file_path = Path(file_path)
                reports_path = file_path.parent / "reports"
                
                # reports 폴더에서 보고서 찾기
                if reports_path.exists():
                    # 1. 원본 파일명으로 찾기 (특수문자 이스케이프 처리)
                    escaped_stem = glob.escape(file_path.stem)
                    pattern = f"*{escaped_stem}*.html"
                    
                    for report_file in reports_path.glob(pattern):
                        webbrowser.open(str(report_file))
                        self.main_window.logger.log(f"보고서 열기: {report_file}")
                        return
                    
                    # 2. 안전한 파일명으로 찾기 (특수문자가 변환된 파일명)
                    safe_stem = self._sanitize_filename(file_path.stem)
                    safe_pattern = f"*{safe_stem}*.html"
                    
                    for report_file in reports_path.glob(safe_pattern):
                        webbrowser.open(str(report_file))
                        self.main_window.logger.log(f"보고서 열기 (안전한 파일명): {report_file}")
                        return
        
        # 대체 방법: 폴더 감시 설정에서 찾기 (기존 방식)
        for config in self.main_window.folder_watcher.folder_configs.values():
            if hasattr(config, 'path') and config.path.name == folder_name:
                reports_path = config.path / "reports"
                
                if reports_path.exists():
                    # 1. 원본 파일명으로 찾기
                    escaped_stem = glob.escape(Path(filename).stem)
                    pattern = f"*{escaped_stem}*.html"
                    
                    for report_file in reports_path.glob(pattern):
                        webbrowser.open(str(report_file))
                        return
                    
                    # 2. 안전한 파일명으로 찾기
                    safe_stem = self._sanitize_filename(Path(filename).stem)
                    safe_pattern = f"*{safe_stem}*.html"
                    
                    for report_file in reports_path.glob(safe_pattern):
                        webbrowser.open(str(report_file))
                        return
        
        # 마지막 대체 방법: 기본 reports 폴더에서 찾기
        default_reports_path = Path("reports")
        if default_reports_path.exists():
            # 1. 원본 파일명으로 찾기
            escaped_stem = glob.escape(Path(filename).stem)
            pattern = f"*{escaped_stem}*.html"
            
            for report_file in default_reports_path.glob(pattern):
                webbrowser.open(str(report_file))
                return
            
            # 2. 안전한 파일명으로 찾기
            safe_stem = self._sanitize_filename(Path(filename).stem)
            safe_pattern = f"*{safe_stem}*.html"
            
            for report_file in default_reports_path.glob(safe_pattern):
                webbrowser.open(str(report_file))
                return
        
        messagebox.showinfo("정보", "보고서를 찾을 수 없습니다.")
    
    def _show_in_folder(self):
        """폴더에서 보기"""
        selection = self.realtime_tree.selection()
        if not selection:
            return
        
        item = self.realtime_tree.item(selection[0])
        folder_name = item['values'][2]  # 폴더
        
        # 폴더 열기
        if folder_name == '드래그앤드롭':
            messagebox.showinfo("정보", "드래그앤드롭으로 추가된 파일입니다.")
        else:
            for config in self.main_window.folder_watcher.folder_configs.values():
                if hasattr(config, 'path') and config.path.name == folder_name:
                    try:
                        os.startfile(str(config.path))
                    except:
                        pass
                    break
    
    def _reprocess_file(self):
        """파일 다시 처리"""
        selection = self.realtime_tree.selection()
        if not selection:
            messagebox.showinfo("정보", "재처리할 파일을 선택하세요.")
            return
        
        messagebox.showinfo("정보", "재처리 기능은 개발 중입니다.")
    
    def _delete_selected(self):
        """선택 항목 삭제"""
        selection = self.realtime_tree.selection()
        if selection:
            if messagebox.askyesno("확인", "선택한 항목을 목록에서 제거하시겠습니까?"):
                for item in selection:
                    # 타이머 정리
                    if item in self.processing_times:
                        del self.processing_times[item]
                    if item in self.timer_threads:
                        del self.timer_threads[item]
                    
                    # PDF 결과 정리 (추가)
                    if item in self.pdf_results:
                        del self.pdf_results[item]
                    
                    # 선택 상태에서도 제거
                    if item in self.selected_items:
                        self.selected_items.remove(item)
                    
                    self.realtime_tree.delete(item)
                
                self._update_selection_count()