# statistics_window.py
"""
통계 대시보드 창
PDF 처리 통계를 시각화하여 표시하는 별도 창입니다.
"""

import tkinter as tk
from tkinter import ttk
import customtkinter as ctk
from datetime import datetime, timedelta
import json

# 차트 라이브러리
try:
    import matplotlib.pyplot as plt
    from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
    from matplotlib.figure import Figure
    import matplotlib.dates as mdates
    HAS_MATPLOTLIB = True
except ImportError:
    HAS_MATPLOTLIB = False
    print("matplotlib이 설치되지 않았습니다. 차트 기능이 제한됩니다.")


class StatisticsWindow:
    """통계 대시보드 창 클래스"""
    
    def __init__(self, parent, main_window):
        """
        통계 창 초기화
        
        Args:
            parent: 부모 윈도우
            main_window: 메인 윈도우 인스턴스
        """
        self.window = ctk.CTkToplevel(parent)
        self.window.title("PDF 검수 통계 대시보드")
        self.window.geometry("1200x800")
        self.window.transient(parent)
        
        self.main_window = main_window
        self.colors = main_window.colors
        self.fonts = main_window.fonts
        
        # 기간 선택 변수
        self.period_var = tk.StringVar(value="week")
        
        # 차트 스타일 설정
        if HAS_MATPLOTLIB:
            self._setup_matplotlib_style()
        
        # UI 생성
        self._create_ui()
        
        # 초기 데이터 로드
        self.refresh_data()
        
        # 창 중앙 배치
        self._center_window()
    
    def _center_window(self):
        """창을 화면 중앙에 배치"""
        self.window.update_idletasks()
        width = self.window.winfo_width()
        height = self.window.winfo_height()
        x = (self.window.winfo_screenwidth() // 2) - (width // 2)
        y = (self.window.winfo_screenheight() // 2) - (height // 2)
        self.window.geometry(f'{width}x{height}+{x}+{y}')
    
    def _setup_matplotlib_style(self):
        """matplotlib 스타일 설정"""
        plt.style.use('dark_background' if self.main_window.current_theme == 'dark' else 'default')
        
        # 차트 색상
        self.chart_colors = {
            'success': '#22c55e',
            'warning': '#f59e0b',
            'error': '#ef4444',
            'info': '#3b82f6',
            'accent': self.colors['accent']
        }
    
    def _create_ui(self):
        """UI 생성"""
        # 메인 컨테이너
        main_container = ctk.CTkFrame(self.window, fg_color="transparent")
        main_container.pack(fill='both', expand=True, padx=20, pady=20)
        
        # 헤더
        self._create_header(main_container)
        
        # 통계 카드들
        self._create_stats_cards(main_container)
        
        # 차트 영역
        self._create_charts_area(main_container)
    
    def _create_header(self, parent):
        """헤더 생성"""
        header_frame = ctk.CTkFrame(parent, fg_color="transparent")
        header_frame.pack(fill='x', pady=(0, 20))
        
        # 제목
        ctk.CTkLabel(
            header_frame,
            text="📊 PDF 검수 통계 대시보드",
            font=self.fonts['heading']
        ).pack(side='left')
        
        # 기간 선택
        period_frame = ctk.CTkFrame(header_frame, fg_color="transparent")
        period_frame.pack(side='right')
        
        periods = [
            ("오늘", "today"),
            ("이번 주", "week"),
            ("이번 달", "month"),
            ("전체", "all")
        ]
        
        for text, value in periods:
            btn = ctk.CTkRadioButton(
                period_frame,
                text=text,
                variable=self.period_var,
                value=value,
                command=self.refresh_data
            )
            btn.pack(side='left', padx=5)
        
        # 새로고침 버튼
        ctk.CTkButton(
            period_frame,
            text="🔄",
            command=self.refresh_data,
            width=40,
            height=32
        ).pack(side='left', padx=(20, 0))
    
    def _create_stats_cards(self, parent):
        """통계 카드들 생성"""
        cards_frame = ctk.CTkFrame(parent, fg_color="transparent")
        cards_frame.pack(fill='x', pady=(0, 20))
        
        # 카드 데이터
        self.card_data = {
            'total': {'label': '총 처리', 'value': '0', 'icon': '📄', 'color': self.colors['accent']},
            'success': {'label': '성공', 'value': '0', 'icon': '✅', 'color': self.chart_colors['success']},
            'warning': {'label': '경고', 'value': '0', 'icon': '⚠️', 'color': self.chart_colors['warning']},
            'error': {'label': '오류', 'value': '0', 'icon': '❌', 'color': self.chart_colors['error']},
            'fixed': {'label': '자동수정', 'value': '0', 'icon': '🔧', 'color': self.chart_colors['info']}
        }
        
        # 카드 위젯 저장
        self.card_widgets = {}
        
        for key, data in self.card_data.items():
            card = self._create_stat_card(cards_frame, data)
            card.pack(side='left', fill='both', expand=True, padx=5)
            self.card_widgets[key] = card
    
    def _create_stat_card(self, parent, data):
        """개별 통계 카드 생성"""
        card = ctk.CTkFrame(
            parent,
            fg_color=self.colors['bg_card'],
            corner_radius=10,
            height=100
        )
        
        inner = ctk.CTkFrame(card, fg_color="transparent")
        inner.pack(fill='both', expand=True, padx=20, pady=15)
        
        # 아이콘과 레이블
        top_frame = ctk.CTkFrame(inner, fg_color="transparent")
        top_frame.pack(fill='x')
        
        ctk.CTkLabel(
            top_frame,
            text=data['icon'],
            font=('Arial', 24)
        ).pack(side='left')
        
        ctk.CTkLabel(
            top_frame,
            text=data['label'],
            font=self.fonts['body'],
            text_color=self.colors['text_secondary']
        ).pack(side='left', padx=(10, 0))
        
        # 값
        data['value_label'] = ctk.CTkLabel(
            inner,
            text=data['value'],
            font=('Arial', 28, 'bold'),
            text_color=data['color']
        )
        data['value_label'].pack(pady=(10, 0))
        
        return card
    
    def _create_charts_area(self, parent):
        """차트 영역 생성"""
        if not HAS_MATPLOTLIB:
            # matplotlib이 없을 때 대체 UI
            self._create_text_stats(parent)
            return
        
        # 노트북 위젯으로 여러 차트 표시
        self.notebook = ttk.Notebook(parent)
        self.notebook.pack(fill='both', expand=True)
        
        # 차트 탭들
        self._create_timeline_chart()
        self._create_issues_chart()
        self._create_folders_chart()
        self._create_performance_chart()
    
    def _create_timeline_chart(self):
        """시간대별 처리 현황 차트"""
        frame = ctk.CTkFrame(self.notebook)
        self.notebook.add(frame, text="시간대별 처리 현황")
        
        # Figure 생성
        fig = Figure(figsize=(10, 6), dpi=100)
        fig.patch.set_facecolor(self.colors['bg_card'])
        
        self.timeline_ax = fig.add_subplot(111)
        self.timeline_ax.set_facecolor(self.colors['bg_card'])
        
        # 캔버스 생성
        self.timeline_canvas = FigureCanvasTkAgg(fig, frame)
        self.timeline_canvas.get_tk_widget().pack(fill='both', expand=True, padx=10, pady=10)
    
    def _create_issues_chart(self):
        """문제 유형별 통계 차트"""
        frame = ctk.CTkFrame(self.notebook)
        self.notebook.add(frame, text="문제 유형별 통계")
        
        fig = Figure(figsize=(10, 6), dpi=100)
        fig.patch.set_facecolor(self.colors['bg_card'])
        
        self.issues_ax = fig.add_subplot(111)
        self.issues_ax.set_facecolor(self.colors['bg_card'])
        
        self.issues_canvas = FigureCanvasTkAgg(fig, frame)
        self.issues_canvas.get_tk_widget().pack(fill='both', expand=True, padx=10, pady=10)
    
    def _create_folders_chart(self):
        """폴더별 처리 통계 차트"""
        frame = ctk.CTkFrame(self.notebook)
        self.notebook.add(frame, text="폴더별 통계")
        
        fig = Figure(figsize=(10, 6), dpi=100)
        fig.patch.set_facecolor(self.colors['bg_card'])
        
        self.folders_ax = fig.add_subplot(111)
        self.folders_ax.set_facecolor(self.colors['bg_card'])
        
        self.folders_canvas = FigureCanvasTkAgg(fig, frame)
        self.folders_canvas.get_tk_widget().pack(fill='both', expand=True, padx=10, pady=10)
    
    def _create_performance_chart(self):
        """성능 통계 차트"""
        frame = ctk.CTkFrame(self.notebook)
        self.notebook.add(frame, text="성능 분석")
        
        fig = Figure(figsize=(10, 6), dpi=100)
        fig.patch.set_facecolor(self.colors['bg_card'])
        
        self.perf_ax = fig.add_subplot(111)
        self.perf_ax.set_facecolor(self.colors['bg_card'])
        
        self.perf_canvas = FigureCanvasTkAgg(fig, frame)
        self.perf_canvas.get_tk_widget().pack(fill='both', expand=True, padx=10, pady=10)
    
    def _create_text_stats(self, parent):
        """텍스트 기반 통계 (matplotlib 없을 때)"""
        stats_frame = ctk.CTkFrame(
            parent,
            fg_color=self.colors['bg_card'],
            corner_radius=10
        )
        stats_frame.pack(fill='both', expand=True)
        
        # 스크롤 가능한 텍스트
        self.stats_text = ctk.CTkTextbox(
            stats_frame,
            font=self.fonts['mono'],
            fg_color=self.colors['bg_secondary']
        )
        self.stats_text.pack(fill='both', expand=True, padx=20, pady=20)
    
    def refresh_data(self):
        """데이터 새로고침"""
        # 기간 계산
        period = self.period_var.get()
        date_range = self._calculate_date_range(period)
        
        # 통계 데이터 가져오기
        stats = self.main_window.data_manager.get_statistics(date_range=date_range)
        
        # 카드 업데이트
        self._update_cards(stats)
        
        # 차트 업데이트
        if HAS_MATPLOTLIB:
            self._update_charts(stats, date_range)
        else:
            self._update_text_stats(stats)
    
    def _calculate_date_range(self, period):
        """기간 계산"""
        today = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
        
        if period == 'today':
            start = today
            end = today + timedelta(days=1)
        elif period == 'week':
            start = today - timedelta(days=today.weekday())
            end = today + timedelta(days=1)
        elif period == 'month':
            start = today.replace(day=1)
            end = today + timedelta(days=1)
        else:  # all
            start = None
            end = None
        
        return (start, end)
    
    def _update_cards(self, stats):
        """카드 값 업데이트"""
        basic = stats.get('basic', {})
        
        updates = {
            'total': str(basic.get('total_files', 0)),
            'success': str(basic.get('success_count', 0)),
            'warning': str(basic.get('warning_count', 0)),
            'error': str(basic.get('total_errors', 0)),
            'fixed': str(basic.get('auto_fixed_count', 0))
        }
        
        for key, value in updates.items():
            if key in self.card_data:
                self.card_data[key]['value_label'].configure(text=value)
    
    def _update_charts(self, stats, date_range):
        """차트 업데이트"""
        # 시간대별 차트
        self._update_timeline_chart(stats.get('timeline', []))
        
        # 문제 유형별 차트
        self._update_issues_chart(stats.get('issue_types', {}))
        
        # 폴더별 차트
        self._update_folders_chart(stats.get('by_folder', {}))
        
        # 성능 차트
        self._update_performance_chart(stats.get('performance', {}))
    
    def _update_timeline_chart(self, timeline_data):
        """시간대별 차트 업데이트"""
        self.timeline_ax.clear()
        
        if not timeline_data:
            self.timeline_ax.text(0.5, 0.5, '데이터 없음', 
                                ha='center', va='center',
                                transform=self.timeline_ax.transAxes)
        else:
            # 데이터 준비
            dates = []
            counts = []
            for item in timeline_data:
                dates.append(item['date'])
                counts.append(item['count'])
            
            # 막대 그래프
            self.timeline_ax.bar(dates, counts, color=self.colors['accent'])
            self.timeline_ax.set_xlabel('날짜')
            self.timeline_ax.set_ylabel('처리 파일 수')
            self.timeline_ax.set_title('일별 처리 현황')
            
            # X축 포맷
            self.timeline_ax.xaxis.set_major_formatter(mdates.DateFormatter('%m/%d'))
            self.timeline_ax.xaxis.set_major_locator(mdates.DayLocator())
            plt.setp(self.timeline_ax.xaxis.get_majorticklabels(), rotation=45)
        
        self.timeline_canvas.draw()
    
    def _update_issues_chart(self, issues_data):
        """문제 유형별 차트 업데이트"""
        self.issues_ax.clear()
        
        if not issues_data:
            self.issues_ax.text(0.5, 0.5, '데이터 없음',
                              ha='center', va='center',
                              transform=self.issues_ax.transAxes)
        else:
            # 파이 차트
            labels = list(issues_data.keys())
            sizes = list(issues_data.values())
            colors = [self.chart_colors.get(label.lower(), '#gray') for label in labels]
            
            self.issues_ax.pie(sizes, labels=labels, colors=colors, autopct='%1.1f%%')
            self.issues_ax.set_title('문제 유형 분포')
        
        self.issues_canvas.draw()
    
    def _update_folders_chart(self, folders_data):
        """폴더별 차트 업데이트"""
        self.folders_ax.clear()
        
        if not folders_data:
            self.folders_ax.text(0.5, 0.5, '데이터 없음',
                               ha='center', va='center',
                               transform=self.folders_ax.transAxes)
        else:
            # 수평 막대 그래프
            folders = list(folders_data.keys())
            counts = list(folders_data.values())
            
            y_pos = range(len(folders))
            self.folders_ax.barh(y_pos, counts, color=self.colors['accent'])
            self.folders_ax.set_yticks(y_pos)
            self.folders_ax.set_yticklabels(folders)
            self.folders_ax.set_xlabel('처리 파일 수')
            self.folders_ax.set_title('폴더별 처리 통계')
        
        self.folders_canvas.draw()
    
    def _update_performance_chart(self, perf_data):
        """성능 차트 업데이트"""
        self.perf_ax.clear()
        
        if not perf_data:
            self.perf_ax.text(0.5, 0.5, '데이터 없음',
                            ha='center', va='center',
                            transform=self.perf_ax.transAxes)
        else:
            # 처리 시간 분포
            times = perf_data.get('processing_times', [])
            if times:
                self.perf_ax.hist(times, bins=20, color=self.colors['accent'])
                self.perf_ax.set_xlabel('처리 시간 (초)')
                self.perf_ax.set_ylabel('파일 수')
                self.perf_ax.set_title('처리 시간 분포')
                
                # 평균선 추가
                avg_time = sum(times) / len(times)
                self.perf_ax.axvline(avg_time, color='red', linestyle='--',
                                   label=f'평균: {avg_time:.1f}초')
                self.perf_ax.legend()
        
        self.perf_canvas.draw()
    
    def _update_text_stats(self, stats):
        """텍스트 통계 업데이트"""
        text = f"""
PDF 검수 통계 ({self.period_var.get()})
{'='*50}

기본 통계:
- 총 처리 파일: {stats['basic']['total_files']}개
- 성공: {stats['basic']['success_count']}개
- 경고: {stats['basic']['warning_count']}개
- 오류: {stats['basic']['total_errors']}개
- 자동 수정: {stats['basic']['auto_fixed_count']}개

성능:
- 평균 처리 시간: {stats['basic']['avg_processing_time']:.1f}초
- 총 페이지: {stats['basic']['total_pages']}페이지

주요 문제:
"""
        
        # 문제 유형별 통계
        for issue_type, count in stats.get('issue_types', {}).items():
            text += f"- {issue_type}: {count}건\n"
        
        self.stats_text.delete('1.0', 'end')
        self.stats_text.insert('1.0', text)