# gui/dialogs/profile_manager_dialog.py
"""
프로파일 관리 대화상자
프로파일 생성, 수정, 삭제 등을 관리하는 UI
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import customtkinter as ctk
from pathlib import Path
from datetime import datetime
import sys
import os

# 부모 디렉토리를 경로에 추가
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(os.path.dirname(current_dir))
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

from profile_manager import get_profile_manager


class ProfileManagerDialog:
    """프로파일 관리 대화상자"""
    
    def __init__(self, parent, main_window=None):
        """
        초기화
        
        Args:
            parent: 부모 윈도우
            main_window: 메인 윈도우 참조 (설정 업데이트용)
        """
        self.parent = parent
        self.main_window = main_window
        self.profile_manager = get_profile_manager()
        
        # 대화상자 생성
        self.dialog = tk.Toplevel(parent)
        self.dialog.title("프로파일 관리")
        self.dialog.geometry("800x600")
        self.dialog.transient(parent)
        
        # 색상 테마
        if main_window:
            self.colors = main_window.colors
            self.fonts = main_window.fonts
        else:
            # 기본 색상
            self.colors = {
                'bg_primary': '#1a1a1a',
                'bg_secondary': '#2d2d2d',
                'bg_card': '#3a3a3a',
                'text_primary': '#ffffff',
                'text_secondary': '#b0b0b0',
                'accent': '#0078d4',
                'success': '#107c10',
                'warning': '#ff8c00',
                'error': '#d83b01',
                'border': '#404040'
            }
            self.fonts = {
                'title': ('맑은 고딕', 16, 'bold'),
                'heading': ('맑은 고딕', 13, 'bold'),
                'body': ('맑은 고딕', 10),
                'small': ('맑은 고딕', 9)
            }
        
        # UI 생성
        self._create_ui()
        
        # 프로파일 목록 로드
        self._refresh_profile_list()
        
        # 중앙 배치
        self._center_dialog()
    
    def _center_dialog(self):
        """대화상자 중앙 배치"""
        self.dialog.update_idletasks()
        width = self.dialog.winfo_width()
        height = self.dialog.winfo_height()
        x = (self.dialog.winfo_screenwidth() // 2) - (width // 2)
        y = (self.dialog.winfo_screenheight() // 2) - (height // 2)
        self.dialog.geometry(f'{width}x{height}+{x}+{y}')
    
    def _create_ui(self):
        """UI 구성"""
        # 메인 프레임
        main_frame = ctk.CTkFrame(self.dialog, fg_color=self.colors['bg_primary'])
        main_frame.pack(fill='both', expand=True)
        
        # 헤더
        self._create_header(main_frame)
        
        # 컨텐츠 영역
        content_frame = ctk.CTkFrame(main_frame, fg_color="transparent")
        content_frame.pack(fill='both', expand=True, padx=20, pady=(0, 20))
        
        # 왼쪽: 프로파일 목록
        self._create_profile_list(content_frame)
        
        # 오른쪽: 상세 정보 및 액션
        self._create_detail_panel(content_frame)
    
    def _create_header(self, parent):
        """헤더 생성"""
        header_frame = ctk.CTkFrame(parent, fg_color="transparent", height=60)
        header_frame.pack(fill='x', padx=20, pady=(20, 10))
        header_frame.pack_propagate(False)
        
        # 제목
        title_label = ctk.CTkLabel(
            header_frame,
            text="프로파일 관리",
            font=self.fonts['title'],
            text_color=self.colors['text_primary']
        )
        title_label.pack(side='left')
        
        # 닫기 버튼
        close_btn = ctk.CTkButton(
            header_frame,
            text="✕ 닫기",
            command=self.dialog.destroy,
            width=80,
            height=32,
            fg_color=self.colors['bg_card'],
            hover_color=self.colors['error']
        )
        close_btn.pack(side='right')
    
    def _create_profile_list(self, parent):
        """프로파일 목록 생성"""
        # 목록 프레임
        list_frame = ctk.CTkFrame(
            parent,
            fg_color=self.colors['bg_card'],
            corner_radius=10,
            width=300
        )
        list_frame.pack(side='left', fill='both', expand=True, padx=(0, 10))
        list_frame.pack_propagate(False)
        
        # 목록 헤더
        list_header = ctk.CTkFrame(list_frame, fg_color="transparent", height=40)
        list_header.pack(fill='x', padx=15, pady=(15, 0))
        
        ctk.CTkLabel(
            list_header,
            text="프로파일 목록",
            font=self.fonts['heading']
        ).pack(side='left')
        
        # 새로 만들기 버튼
        new_btn = ctk.CTkButton(
            list_header,
            text="+ 새로 만들기",
            command=self._create_new_profile,
            width=100,
            height=28,
            fg_color=self.colors['accent']
        )
        new_btn.pack(side='right')
        
        # 목록 컨테이너
        list_container = ctk.CTkFrame(list_frame, fg_color="transparent")
        list_container.pack(fill='both', expand=True, padx=15, pady=15)
        
        # 스크롤 가능한 프레임
        self.profile_scroll = ctk.CTkScrollableFrame(
            list_container,
            fg_color="transparent"
        )
        self.profile_scroll.pack(fill='both', expand=True)
        
        # 프로파일 아이템들이 여기에 추가됨
        self.profile_items = {}
    
    def _create_detail_panel(self, parent):
        """상세 정보 패널 생성"""
        # 상세 정보 프레임
        self.detail_frame = ctk.CTkFrame(
            parent,
            fg_color=self.colors['bg_card'],
            corner_radius=10,
            width=400
        )
        self.detail_frame.pack(side='right', fill='both', expand=True)
        self.detail_frame.pack_propagate(False)
        
        # 초기 메시지
        self._show_empty_state()
    
    def _show_empty_state(self):
        """빈 상태 표시"""
        # 기존 위젯 제거
        for widget in self.detail_frame.winfo_children():
            widget.destroy()
        
        # 중앙 메시지
        empty_container = ctk.CTkFrame(self.detail_frame, fg_color="transparent")
        empty_container.place(relx=0.5, rely=0.5, anchor='center')
        
        ctk.CTkLabel(
            empty_container,
            text="프로파일을 선택하세요",
            font=self.fonts['heading'],
            text_color=self.colors['text_secondary']
        ).pack()
    
    def _show_profile_detail(self, profile_info):
        """프로파일 상세 정보 표시"""
        # 기존 위젯 제거
        for widget in self.detail_frame.winfo_children():
            widget.destroy()
        
        # 컨테이너
        detail_container = ctk.CTkFrame(self.detail_frame, fg_color="transparent")
        detail_container.pack(fill='both', expand=True, padx=20, pady=20)
        
        # 프로파일 이름 (편집 가능)
        name_frame = ctk.CTkFrame(detail_container, fg_color="transparent")
        name_frame.pack(fill='x', pady=(0, 15))
        
        ctk.CTkLabel(name_frame, text="프로파일 이름:", font=self.fonts['body']).pack(anchor='w')
        self.name_entry = ctk.CTkEntry(
            name_frame,
            height=35,
            font=self.fonts['body']
        )
        self.name_entry.pack(fill='x', pady=(5, 0))
        self.name_entry.insert(0, profile_info['name'])
        
        # 설명 (편집 가능)
        desc_frame = ctk.CTkFrame(detail_container, fg_color="transparent")
        desc_frame.pack(fill='x', pady=(0, 15))
        
        ctk.CTkLabel(desc_frame, text="설명:", font=self.fonts['body']).pack(anchor='w')
        self.desc_text = tk.Text(
            desc_frame,
            height=4,
            font=self.fonts['body'],
            bg=self.colors['bg_secondary'],
            fg=self.colors['text_primary'],
            insertbackground=self.colors['text_primary']
        )
        self.desc_text.pack(fill='x', pady=(5, 0))
        self.desc_text.insert('1.0', profile_info.get('description', ''))
        
        # 정보
        info_frame = ctk.CTkFrame(detail_container, fg_color=self.colors['bg_secondary'], corner_radius=8)
        info_frame.pack(fill='x', pady=(0, 20))
        
        info_inner = ctk.CTkFrame(info_frame, fg_color="transparent")
        info_inner.pack(padx=15, pady=15)
        
        # 파일명
        ctk.CTkLabel(
            info_inner,
            text=f"파일: {profile_info['filename']}.json",
            font=self.fonts['small'],
            text_color=self.colors['text_secondary']
        ).pack(anchor='w', pady=2)
        
        # 수정일
        if 'modified_date' in profile_info:
            try:
                modified = datetime.fromisoformat(profile_info['modified_date'])
                modified_str = modified.strftime("%Y-%m-%d %H:%M")
            except:
                modified_str = profile_info['modified_date']
                
            ctk.CTkLabel(
                info_inner,
                text=f"수정일: {modified_str}",
                font=self.fonts['small'],
                text_color=self.colors['text_secondary']
            ).pack(anchor='w', pady=2)
        
        # 기본 프로파일 표시
        if profile_info.get('is_default'):
            ctk.CTkLabel(
                info_inner,
                text="⭐ 기본 프로파일",
                font=self.fonts['small'],
                text_color=self.colors['warning']
            ).pack(anchor='w', pady=2)
        
        # 액션 버튼들
        self._create_action_buttons(detail_container, profile_info)
    
    def _create_action_buttons(self, parent, profile_info):
        """액션 버튼 생성"""
        # 버튼 프레임
        btn_frame = ctk.CTkFrame(parent, fg_color="transparent")
        btn_frame.pack(fill='x', pady=(20, 0))
        
        # 저장 버튼
        save_btn = ctk.CTkButton(
            btn_frame,
            text="💾 변경사항 저장",
            command=lambda: self._save_profile_changes(profile_info),
            height=35,
            fg_color=self.colors['success']
        )
        save_btn.pack(fill='x', pady=(0, 10))
        
        # 적용 버튼 (기본 프로파일이 아닌 경우만)
        if not profile_info.get('is_default'):
            apply_btn = ctk.CTkButton(
                btn_frame,
                text="✅ 현재 설정에 적용",
                command=lambda: self._apply_profile(profile_info),
                height=35,
                fg_color=self.colors['accent']
            )
            apply_btn.pack(fill='x', pady=(0, 10))
        
        # 중간 버튼들
        mid_frame = ctk.CTkFrame(btn_frame, fg_color="transparent")
        mid_frame.pack(fill='x', pady=(0, 10))
        
        # 복제 버튼
        duplicate_btn = ctk.CTkButton(
            mid_frame,
            text="📋 복제",
            command=lambda: self._duplicate_profile(profile_info),
            width=100,
            height=32,
            fg_color=self.colors['bg_secondary']
        )
        duplicate_btn.pack(side='left', padx=(0, 5))
        
        # 내보내기 버튼
        export_btn = ctk.CTkButton(
            mid_frame,
            text="📤 내보내기",
            command=lambda: self._export_profile(profile_info),
            width=100,
            height=32,
            fg_color=self.colors['bg_secondary']
        )
        export_btn.pack(side='left', padx=5)
        
        # 삭제 버튼 (기본 프로파일이 아닌 경우만)
        if not profile_info.get('is_default'):
            delete_btn = ctk.CTkButton(
                btn_frame,
                text="🗑️ 삭제",
                command=lambda: self._delete_profile(profile_info),
                height=32,
                fg_color=self.colors['error'],
                hover_color='#ff0000'
            )
            delete_btn.pack(fill='x')
    
    def _refresh_profile_list(self):
        """프로파일 목록 새로고침"""
        # 기존 아이템 제거
        for widget in self.profile_items.values():
            widget.destroy()
        self.profile_items.clear()
        
        # 프로파일 목록 로드
        profiles = self.profile_manager.get_profile_list()
        
        # 프로파일 아이템 생성
        for profile in profiles:
            self._create_profile_item(profile)
    
    def _create_profile_item(self, profile_info):
        """프로파일 목록 아이템 생성"""
        # 아이템 프레임
        item_frame = ctk.CTkFrame(
            self.profile_scroll,
            fg_color=self.colors['bg_secondary'],
            corner_radius=8,
            height=80,
            cursor="hand2"
        )
        item_frame.pack(fill='x', pady=(0, 10))
        item_frame.pack_propagate(False)
        
        # 클릭 이벤트
        item_frame.bind("<Button-1>", lambda e: self._on_profile_selected(profile_info))
        
        # 내부 컨테이너
        inner = ctk.CTkFrame(item_frame, fg_color="transparent")
        inner.pack(fill='both', expand=True, padx=15, pady=12)
        inner.bind("<Button-1>", lambda e: self._on_profile_selected(profile_info))
        
        # 프로파일 이름
        name_label = ctk.CTkLabel(
            inner,
            text=profile_info['name'],
            font=self.fonts['body'],
            anchor='w'
        )
        name_label.pack(fill='x')
        name_label.bind("<Button-1>", lambda e: self._on_profile_selected(profile_info))
        
        # 설명
        if profile_info.get('description'):
            desc_label = ctk.CTkLabel(
                inner,
                text=profile_info['description'][:50] + "..." if len(profile_info['description']) > 50 else profile_info['description'],
                font=self.fonts['small'],
                text_color=self.colors['text_secondary'],
                anchor='w'
            )
            desc_label.pack(fill='x', pady=(2, 0))
            desc_label.bind("<Button-1>", lambda e: self._on_profile_selected(profile_info))
        
        # 기본 프로파일 표시
        if profile_info.get('is_default'):
            default_label = ctk.CTkLabel(
                inner,
                text="⭐ 기본",
                font=self.fonts['small'],
                text_color=self.colors['warning']
            )
            default_label.place(relx=1.0, rely=0, anchor='ne')
        
        # 저장
        self.profile_items[profile_info['filename']] = item_frame
    
    def _on_profile_selected(self, profile_info):
        """프로파일 선택 이벤트"""
        # 모든 아이템 스타일 초기화
        for item in self.profile_items.values():
            item.configure(fg_color=self.colors['bg_secondary'])
        
        # 선택된 아이템 하이라이트
        if profile_info['filename'] in self.profile_items:
            self.profile_items[profile_info['filename']].configure(
                fg_color=self.colors['accent']
            )
        
        # 상세 정보 표시
        self._show_profile_detail(profile_info)
    
    def _create_new_profile(self):
        """새 프로파일 생성"""
        # 이름 입력 대화상자
        dialog = ctk.CTkInputDialog(
            text="새 프로파일 이름을 입력하세요:",
            title="새 프로파일"
        )
        name = dialog.get_input()
        
        if name:
            # 현재 설정으로 새 프로파일 생성
            filename = self.profile_manager.create_profile_from_current_settings(name)
            
            if filename:
                messagebox.showinfo("성공", f"'{name}' 프로파일이 생성되었습니다.")
                self._refresh_profile_list()
            else:
                messagebox.showerror("오류", "프로파일 생성에 실패했습니다.")
    
    def _save_profile_changes(self, profile_info):
        """프로파일 변경사항 저장"""
        if not hasattr(self, 'name_entry'):
            return
        
        new_name = self.name_entry.get().strip()
        new_desc = self.desc_text.get('1.0', 'end-1c').strip()
        
        if not new_name:
            messagebox.showwarning("경고", "프로파일 이름을 입력하세요.")
            return
        
        # 이름 변경
        if new_name != profile_info['name']:
            self.profile_manager.rename_profile(profile_info['filename'], new_name)
        
        # 설명 변경
        self.profile_manager.update_profile_description(profile_info['filename'], new_desc)
        
        messagebox.showinfo("성공", "변경사항이 저장되었습니다.")
        self._refresh_profile_list()
    
    def _apply_profile(self, profile_info):
        """프로파일을 현재 설정에 적용"""
        if messagebox.askyesno("확인", f"'{profile_info['name']}' 프로파일을 현재 설정에 적용하시겠습니까?\n\n현재 설정이 덮어씌워집니다."):
            if self.profile_manager.apply_profile_to_settings(profile_info['filename']):
                messagebox.showinfo("성공", "프로파일이 적용되었습니다.")
                
                # 메인 윈도우가 있으면 설정 재로드
                if self.main_window:
                    try:
                        from config import Config
                        Config.reload_user_settings()
                    except:
                        pass
            else:
                messagebox.showerror("오류", "프로파일 적용에 실패했습니다.")
    
    def _duplicate_profile(self, profile_info):
        """프로파일 복제"""
        # 새 이름 입력
        dialog = ctk.CTkInputDialog(
            text="복제할 프로파일의 이름을 입력하세요:",
            title="프로파일 복제"
        )
        new_name = dialog.get_input()
        
        if new_name:
            filename = self.profile_manager.duplicate_profile(profile_info['filename'], new_name)
            
            if filename:
                messagebox.showinfo("성공", f"'{new_name}' 프로파일이 생성되었습니다.")
                self._refresh_profile_list()
            else:
                messagebox.showerror("오류", "프로파일 복제에 실패했습니다.")
    
    def _export_profile(self, profile_info):
        """프로파일 내보내기"""
        filename = filedialog.asksaveasfilename(
            defaultextension=".json",
            filetypes=[("JSON 파일", "*.json"), ("모든 파일", "*.*")],
            initialfile=f"{profile_info['filename']}.json"
        )
        
        if filename:
            if self.profile_manager.export_profile(profile_info['filename'], filename):
                messagebox.showinfo("성공", "프로파일을 내보냈습니다.")
            else:
                messagebox.showerror("오류", "프로파일 내보내기에 실패했습니다.")
    
    def _delete_profile(self, profile_info):
        """프로파일 삭제"""
        if messagebox.askyesno("확인", f"'{profile_info['name']}' 프로파일을 삭제하시겠습니까?\n\n이 작업은 되돌릴 수 없습니다."):
            if self.profile_manager.delete_profile(profile_info['filename']):
                messagebox.showinfo("성공", "프로파일이 삭제되었습니다.")
                self._refresh_profile_list()
                self._show_empty_state()
            else:
                messagebox.showerror("오류", "프로파일 삭제에 실패했습니다.")
    
    def run(self):
        """대화상자 실행"""
        self.dialog.grab_set()
        self.dialog.wait_window()