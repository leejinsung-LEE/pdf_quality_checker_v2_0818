# gui/components/sidebar.py
"""
사이드바 컴포넌트 - 개선된 버전
드래그앤드롭 즉시 처리와 폴더별 관리 기능이 통합된 사이드바
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import customtkinter as ctk
from pathlib import Path
from datetime import datetime, timedelta
import json

# 프로파일 관리 관련 임포트 추가
from profile_manager import get_profile_manager

# tkinterdnd2 임포트
try:
    from tkinterdnd2 import DND_FILES
    HAS_DND = True
except ImportError:
    HAS_DND = False


class Sidebar:
    """개선된 사이드바 컴포넌트 클래스"""
    
    def __init__(self, main_window, parent):
        """
        사이드바 초기화
        
        Args:
            main_window: 메인 윈도우 인스턴스 (EnhancedPDFCheckerGUI)
            parent: 부모 위젯
        """
        self.main_window = main_window
        self.parent = parent
        
        # 폴더 아이템 관리용 딕셔너리
        self.folder_widgets = {}
        
        # 최근 사용 설정 로드
        self.recent_settings = []
        self.load_recent_settings()
        
        # 사이드바 생성
        self._create_sidebar()
    
    def _create_sidebar(self):
        """사이드바 생성"""
        # 사이드바 프레임 (너비 축소: 300 -> 250)
        self.sidebar = ctk.CTkFrame(
            self.parent, 
            width=250, 
            corner_radius=0, 
            fg_color=self.main_window.colors['bg_secondary']
        )
        self.sidebar.pack(side='left', fill='y', padx=(0, 1))
        self.sidebar.pack_propagate(False)
        
        # 스크롤 가능한 컨테이너
        self.scrollable_frame = ctk.CTkScrollableFrame(
            self.sidebar,
            fg_color="transparent",
            corner_radius=0
        )
        self.scrollable_frame.pack(fill='both', expand=True, padx=0, pady=0)
        
        # 로고/타이틀
        self._create_title_section()
        
        # 구분선
        self._create_separator()
        
        # 폴더 섹션
        self._create_folder_section()
        
        # 구분선
        self._create_separator()
        
        # 드래그앤드롭 섹션
        self._create_drop_section()
        
        # 최근 사용 설정 섹션
        self._create_recent_settings_section()
        
        # 초기 폴더 목록 업데이트
        self.update_folder_list()
    
    def _create_title_section(self):
        """타이틀 섹션 생성"""
        title_frame = ctk.CTkFrame(self.scrollable_frame, fg_color="transparent")
        title_frame.pack(fill='x', padx=20, pady=(25, 20))
        
        logo_label = ctk.CTkLabel(title_frame, text="📊", font=('Arial', 36))
        logo_label.pack(side='left', padx=(0, 15))
        
        title_info = ctk.CTkFrame(title_frame, fg_color="transparent")
        title_info.pack(side='left', fill='both', expand=True)
        
        title_label = ctk.CTkLabel(
            title_info, 
            text="PDF 검수 시스템", 
            font=self.main_window.fonts['heading'],
            text_color=self.main_window.colors['text_primary']
        )
        title_label.pack(anchor='w')
        
        version_label = ctk.CTkLabel(
            title_info, 
            text="v4.0 Enhanced", 
            font=self.main_window.fonts['small'],
            text_color=self.main_window.colors['text_secondary']
        )
        version_label.pack(anchor='w')
    
    def _create_separator(self):
        """구분선 생성"""
        ctk.CTkFrame(
            self.scrollable_frame, 
            height=2, 
            fg_color=self.main_window.colors['border']
        ).pack(fill='x', padx=20, pady=10)
    
    def _create_folder_section(self):
        """폴더 섹션 생성"""
        # 헤더
        folder_header = ctk.CTkFrame(self.scrollable_frame, fg_color="transparent")
        folder_header.pack(fill='x', padx=20, pady=(0, 10))
        
        ctk.CTkLabel(
            folder_header,
            text="📁 감시 폴더",
            font=self.main_window.fonts['subheading']
        ).pack(side='left')
        
        # 폴더 추가 버튼
        add_folder_btn = ctk.CTkButton(
            folder_header,
            text="+",
            command=self.main_window.add_watch_folder,
            width=28,
            height=28,
            font=self.main_window.fonts['body']
        )
        add_folder_btn.pack(side='right')
        
        # 감시 토글 스위치
        self.watch_toggle_switch = ctk.CTkSwitch(
            self.scrollable_frame,
            text="폴더 감시",
            command=self.main_window.toggle_folder_watching,
            button_color=self.main_window.colors['accent'],
            progress_color=self.main_window.colors['success'],
            font=self.main_window.fonts['body'],
            width=60,
            height=24
        )
        self.watch_toggle_switch.pack(fill='x', padx=20, pady=(0, 10))
        
        # 폴더 목록 컨테이너
        self.folder_list_container = ctk.CTkFrame(
            self.scrollable_frame,
            fg_color=self.main_window.colors['bg_card'],
            corner_radius=8
        )
        self.folder_list_container.pack(fill='x', padx=20, pady=(0, 10))
        
        # 기존 리스트박스 (호환성 유지용, 숨김)
        self.folder_listbox = tk.Listbox(self.folder_list_container)
        # 실제로 화면에 표시하지 않음
    
    def _create_drop_section(self):
        """드래그앤드롭 섹션 - 즉시 처리"""
        # 섹션 제목
        ctk.CTkLabel(
            self.scrollable_frame,
            text="즉시 처리",
            font=self.main_window.fonts['subheading']
        ).pack(pady=(0, 10), padx=20, anchor='w')
        
        # 드롭존 프레임
        self.drop_frame = ctk.CTkFrame(
            self.scrollable_frame,
            fg_color=self.main_window.colors['bg_card'],
            corner_radius=10,
            border_width=2,
            border_color=self.main_window.colors['border'],
            height=100
        )
        self.drop_frame.pack(fill='x', padx=20, pady=(0, 10))
        self.drop_frame.pack_propagate(False)
        
        # 드롭 콘텐츠
        drop_content = ctk.CTkFrame(self.drop_frame, fg_color="transparent")
        drop_content.place(relx=0.5, rely=0.5, anchor='center')
        
        # 아이콘과 텍스트
        ctk.CTkLabel(drop_content, text="📄", font=('Arial', 28)).pack()
        self.drop_label = ctk.CTkLabel(
            drop_content,
            text="PDF 드래그앤드롭\n또는 클릭",
            font=self.main_window.fonts['small'],
            text_color=self.main_window.colors['text_secondary']
        )
        self.drop_label.pack()
        
        # 클릭 이벤트
        self.drop_frame.bind("<Button-1>", lambda e: self.browse_files())
        drop_content.bind("<Button-1>", lambda e: self.browse_files())
        
        # 드래그앤드롭 설정
        if HAS_DND:
            self._setup_drag_drop()
        
        # 프로파일 선택 섹션을 드롭존 밖으로 분리
        profile_select_frame = ctk.CTkFrame(
            self.scrollable_frame,
            fg_color=self.main_window.colors['bg_card'],
            corner_radius=8
        )
        profile_select_frame.pack(fill='x', padx=20, pady=(0, 10))

        profile_inner = ctk.CTkFrame(profile_select_frame, fg_color="transparent")
        profile_inner.pack(padx=12, pady=8)

        ctk.CTkLabel(
            profile_inner, 
            text="프로파일:", 
            font=self.main_window.fonts['small'],
            text_color=self.main_window.colors['text_secondary']
        ).pack(side='left', padx=(0, 8))

        self.profile_var = tk.StringVar(value="default")
        self.profile_combo = ctk.CTkComboBox(
            profile_inner,
            variable=self.profile_var,
            values=self._get_profile_names(),
            width=140,
            height=26,
            font=self.main_window.fonts['small'],
            dropdown_font=self.main_window.fonts['small'],
            button_color=self.main_window.colors['accent'],
            button_hover_color=self.main_window.colors['accent'],
            dropdown_fg_color=self.main_window.colors['bg_card'],
            dropdown_text_color=self.main_window.colors['text_primary'],
            dropdown_hover_color=self.main_window.colors['bg_secondary']
        )
        self.profile_combo.pack(side='left')
        
        # 처리 옵션
        self._create_process_options()
    
    def _get_profile_names(self):
        """프로파일 이름 목록 가져오기"""
        profile_manager = get_profile_manager()
        profiles = profile_manager.get_profile_list()
        
        # 표시용 이름 리스트 생성
        display_names = []
        self.profile_mapping = {}  # 표시명 -> 파일명 매핑
        
        for p in profiles:
            display_name = p['name']
            if p.get('is_default'):
                display_name += " (기본)"
            display_names.append(display_name)
            self.profile_mapping[display_name] = p['filename']
        
        return display_names

    def update_profile_list(self):
        """프로파일 목록 업데이트"""
        if hasattr(self, 'profile_combo'):
            profile_names = self._get_profile_names()
            self.profile_combo.configure(values=profile_names)
            
            # 현재 선택값이 목록에 없으면 기본값으로
            if self.profile_combo.get() not in profile_names:
                self.profile_combo.set(profile_names[0] if profile_names else "기본")
    
    def _create_process_options(self):
        """처리 옵션 섹션"""
        options_frame = ctk.CTkFrame(
            self.scrollable_frame,
            fg_color=self.main_window.colors['bg_card'],
            corner_radius=8
        )
        options_frame.pack(fill='x', padx=20, pady=(0, 10))
        
        options_inner = ctk.CTkFrame(options_frame, fg_color="transparent")
        options_inner.pack(padx=12, pady=12)
        
        # 자동 수정 체크박스
        self.auto_fix_var = tk.BooleanVar(value=False)
        self.auto_fix_check = ctk.CTkCheckBox(
            options_inner,
            text="자동 수정",
            variable=self.auto_fix_var,
            font=self.main_window.fonts['body'],
            height=22,
            command=self._save_recent_setting
        )
        self.auto_fix_check.pack(fill='x', pady=3)
        
        # 잉크량 분석 체크박스
        self.ink_analysis_var = tk.BooleanVar(value=False)
        self.ink_check = ctk.CTkCheckBox(
            options_inner,
            text="잉크량 분석",
            variable=self.ink_analysis_var,
            font=self.main_window.fonts['body'],
            height=22,
            command=self._save_recent_setting
        )
        self.ink_check.pack(fill='x', pady=3)
        
        # 세부 설정 버튼
        self.detail_settings_btn = ctk.CTkButton(
            options_inner,
            text="⚙️ 세부 설정",
            command=self._open_detail_settings,
            width=140,
            height=28,
            fg_color=self.main_window.colors['bg_secondary'],
            hover_color=self.main_window.colors['accent'],
            font=self.main_window.fonts['small']
        )
        self.detail_settings_btn.pack(pady=(8, 0))
    
    def _create_recent_settings_section(self):
        """최근 사용 설정 섹션"""
        if not self.recent_settings:
            return
        
        # 섹션 제목
        ctk.CTkLabel(
            self.scrollable_frame,
            text="최근 사용 설정",
            font=self.main_window.fonts['small'],
            text_color=self.main_window.colors['text_secondary']
        ).pack(padx=20, pady=(10, 5), anchor='w')
        
        # 최근 설정 버튼들
        for setting in self.recent_settings[:3]:  # 최대 3개만 표시
            btn_text = self._format_setting_text(setting)
            btn = ctk.CTkButton(
                self.scrollable_frame,
                text=btn_text,
                command=lambda s=setting: self._apply_recent_setting(s),
                width=180,
                height=24,
                fg_color=self.main_window.colors['bg_card'],
                hover_color=self.main_window.colors['accent'],
                font=self.main_window.fonts['small']
            )
            btn.pack(padx=20, pady=2)
    
    def update_folder_list(self):
        """폴더 목록 업데이트"""
        # 기존 위젯들 제거
        for widget_dict in self.folder_widgets.values():
            widget_dict['frame'].destroy()
        self.folder_widgets.clear()
        
        # 리스트박스도 업데이트 (호환성)
        self.folder_listbox.delete(0, tk.END)
        
        # 폴더 목록 가져오기
        folder_list = self.main_window.folder_watcher.get_folder_list()
        
        for idx, folder in enumerate(folder_list):
            # 폴더 아이템 프레임
            item_frame = ctk.CTkFrame(
                self.folder_list_container,
                fg_color="transparent",
                height=35
            )
            item_frame.pack(fill='x', padx=10, pady=2)
            
            # 활성화 체크박스
            active_var = tk.BooleanVar(value=folder['enabled'])
            checkbox = ctk.CTkCheckBox(
                item_frame,
                text="",
                variable=active_var,
                command=lambda p=folder['path'], v=active_var: self._toggle_folder_active(p, v.get()),
                width=20,
                height=20
            )
            checkbox.pack(side='left', padx=(0, 5))
            
            # 폴더명
            folder_text = f"📁 {folder['name']} ({folder['profile']})"
            name_label = ctk.CTkLabel(
                item_frame,
                text=folder_text,
                font=self.main_window.fonts['small'],
                anchor='w'
            )
            name_label.pack(side='left', fill='x', expand=True)
            
            # 설정 버튼
            settings_btn = ctk.CTkButton(
                item_frame,
                text="⚙️",
                command=lambda p=folder['path']: self._edit_folder_settings(p),
                width=28,
                height=28,
                fg_color="transparent",
                hover_color=self.main_window.colors['bg_card'],
                font=('Arial', 12)
            )
            settings_btn.pack(side='left', padx=2)
            
            # 삭제 버튼
            delete_btn = ctk.CTkButton(
                item_frame,
                text="✕",
                command=lambda p=folder['path'], n=folder['name']: self._remove_folder(p, n),
                width=28,
                height=28,
                fg_color="transparent",
                hover_color=self.main_window.colors['error'],
                text_color=self.main_window.colors['error'],
                font=('Arial', 12)
            )
            delete_btn.pack(side='left')
            
            # 리스트박스에도 추가 (호환성)
            status = "✓" if folder['enabled'] else "✗"
            ink = "🎨" if folder.get('auto_fix_settings', {}).get('include_ink_analysis', False) else ""
            text = f"{status} {folder['name']} ({folder['profile']}) {ink}"
            self.folder_listbox.insert(tk.END, text)
            
            # 위젯 저장
            self.folder_widgets[folder['path']] = {
                'frame': item_frame,
                'checkbox': checkbox,
                'active_var': active_var
            }
    
    def _toggle_folder_active(self, folder_path: str, active: bool):
        """폴더 활성화 상태 토글"""
        # FolderConfig 가져오기
        folder_config = self.main_window.folder_watcher.folder_configs.get(folder_path)
        if folder_config:
            folder_config.enabled = active
            self.main_window.folder_watcher._save_config()
            
            # UI 업데이트
            if folder_path in self.folder_widgets:
                if active:
                    self.folder_widgets[folder_path]['frame'].configure(fg_color="transparent")
                else:
                    self.folder_widgets[folder_path]['frame'].configure(
                        fg_color=self.main_window.colors['bg_secondary']
                    )
    
    def _edit_folder_settings(self, folder_path: str):
        """폴더 설정 편집"""
        # 선택 상태 설정 (호환성)
        folder_list = self.main_window.folder_watcher.get_folder_list()
        for idx, folder in enumerate(folder_list):
            if folder['path'] == folder_path:
                self.folder_listbox.selection_clear(0, tk.END)
                self.folder_listbox.selection_set(idx)
                break
        
        # 편집 대화상자 열기
        self.main_window.edit_folder_settings()
    
    def _remove_folder(self, folder_path: str, folder_name: str):
        """폴더 제거"""
        if messagebox.askyesno("확인", f"'{folder_name}' 폴더를 제거하시겠습니까?"):
            if self.main_window.folder_watcher.remove_folder(folder_path):
                self.update_folder_list()
                self.main_window.logger.log(f"감시 폴더 제거: {folder_name}")
    
    def _setup_drag_drop(self):
        """드래그앤드롭 설정"""
        def drop_enter(event):
            self.drop_frame.configure(border_color=self.main_window.colors['accent'])
            self.drop_label.configure(
                text="놓으세요!", 
                text_color=self.main_window.colors['accent']
            )
            
            # 드래그 중인 파일 수와 처리 방식 표시
            files = self._parse_drop_files(event.data)
            pdf_count = sum(1 for f in files if f.lower().endswith('.pdf'))
            if pdf_count > 0:
                settings = self._get_current_settings_text()
                self.drop_label.configure(
                    text=f"{pdf_count}개 파일\n{settings}"
                )
            return event.action
        
        def drop_leave(event):
            self.drop_frame.configure(border_color=self.main_window.colors['border'])
            self.drop_label.configure(
                text="PDF 드래그앤드롭\n또는 클릭",
                text_color=self.main_window.colors['text_secondary']
            )
            return event.action
        
        def drop_files(event):
            files = self._parse_drop_files(event.data)
            pdf_files = [f for f in files if f.lower().endswith('.pdf')]
            
            if pdf_files:
                # 즉시 처리
                self._process_files_immediately(pdf_files)
                drop_leave(event)
            else:
                messagebox.showwarning("경고", "PDF 파일만 처리할 수 있습니다.")
            
            return event.action
        
        # 드래그앤드롭 이벤트 바인딩
        self.drop_frame.drop_target_register(DND_FILES)
        self.drop_frame.dnd_bind('<<DropEnter>>', drop_enter)
        self.drop_frame.dnd_bind('<<DropLeave>>', drop_leave)
        self.drop_frame.dnd_bind('<<Drop>>', drop_files)
    
    def _parse_drop_files(self, data):
        """드롭된 파일 경로 파싱"""
        files = []
        if isinstance(data, str):
            # Windows: 중괄호로 감싸진 경로 처리
            if data.startswith('{') and data.endswith('}'):
                files = data[1:-1].split('} {')
            else:
                files = data.split()
        return files
    
    def _process_files_immediately(self, pdf_files):
        """파일 즉시 처리"""
        # 선택된 프로파일 가져오기
        display_name = self.profile_combo.get() if hasattr(self, 'profile_combo') else "기본"
        profile_filename = self.profile_mapping.get(display_name, 'default')
        
        # 프로파일 데이터 로드
        profile_manager = get_profile_manager()
        profile_data = profile_manager.load_profile(profile_filename)
        
        if not profile_data:
            # 기본 프로파일 사용
            profile_data = profile_manager.load_profile('default')
            profile_filename = 'default'
        
        # 폴더 설정 형태로 만들기
        folder_config = {
            'profile': profile_filename,
            'auto_fix_settings': {
                'auto_convert_rgb': profile_data.get('auto_fix_options', {}).get('convert_rgb_to_cmyk', False),
                'auto_outline_fonts': profile_data.get('auto_fix_options', {}).get('outline_fonts', False),
                'include_ink_analysis': profile_data.get('check_options', {}).get('ink_coverage', False)
            }
        }
        
        # 현재 설정을 최근 사용에 저장
        self._save_recent_setting()
        
        # 각 파일을 실시간 탭으로 전송하여 처리
        for file_path in pdf_files:
            self.main_window.realtime_tab.add_file_to_process(
                Path(file_path),
                folder_config
            )
        
        self.main_window.logger.log(f"{len(pdf_files)}개 파일 처리 시작 (프로파일: {profile_data['profile_info']['name']})")
        
        # 처리 시작 피드백
        self.drop_frame.configure(border_color=self.main_window.colors['success'])
        self.drop_label.configure(
            text=f"✅ {len(pdf_files)}개 처리 중",
            text_color=self.main_window.colors['success']
        )
        
        # 2초 후 원래 상태로 복귀
        self.main_window.root.after(2000, self._reset_drop_zone)
    
    def _reset_drop_zone(self):
        """드롭존을 원래 상태로 복귀"""
        self.drop_frame.configure(border_color=self.main_window.colors['border'])
        self.drop_label.configure(
            text="PDF 드래그앤드롭\n또는 클릭",
            text_color=self.main_window.colors['text_secondary']
        )
    
    def browse_files(self):
        """파일 선택 대화상자"""
        files = filedialog.askopenfilenames(
            title="PDF 파일 선택",
            filetypes=[("PDF files", "*.pdf"), ("All files", "*.*")]
        )
        
        if files:
            self._process_files_immediately(list(files))
    
    def _open_detail_settings(self):
        """세부 설정 창 열기"""
        # 세부 설정 창 구현
        detail_window = tk.Toplevel(self.main_window.root)
        detail_window.title("세부 처리 설정")
        detail_window.geometry("400x500")
        detail_window.transient(self.main_window.root)
        
        # 설정 내용 구현
        frame = ctk.CTkFrame(detail_window)
        frame.pack(fill='both', expand=True, padx=20, pady=20)
        
        ctk.CTkLabel(
            frame,
            text="세부 처리 설정",
            font=self.main_window.fonts['heading']
        ).pack(pady=(0, 20))
        
        # 프로파일 선택
        ctk.CTkLabel(frame, text="프로파일:", font=self.main_window.fonts['body']).pack(anchor='w')
        profile_var = tk.StringVar(value='offset')
        profile_menu = ctk.CTkOptionMenu(
            frame,
            variable=profile_var,
            values=['offset', 'digital', 'web', 'proof']
        )
        profile_menu.pack(fill='x', pady=(5, 15))
        
        # 추가 옵션들을 여기에 구현
        
        # 닫기 버튼
        ctk.CTkButton(
            frame,
            text="확인",
            command=detail_window.destroy
        ).pack(pady=20)
    
    def _get_current_settings_text(self):
        """현재 설정을 텍스트로 반환"""
        settings = []
        if self.auto_fix_var.get():
            settings.append("자동수정")
        if self.ink_analysis_var.get():
            settings.append("잉크분석")
        
        if settings:
            return " + ".join(settings)
        else:
            return "기본 설정"
    
    def _save_recent_setting(self):
        """현재 설정을 최근 사용에 저장"""
        current = {
            'auto_fix': self.auto_fix_var.get(),
            'ink_analysis': self.ink_analysis_var.get()
        }
        
        # 중복 제거
        self.recent_settings = [s for s in self.recent_settings if s != current]
        
        # 맨 앞에 추가
        self.recent_settings.insert(0, current)
        
        # 최대 5개만 유지
        self.recent_settings = self.recent_settings[:5]
        
        # 파일에 저장
        try:
            with open('recent_settings.json', 'w', encoding='utf-8') as f:
                json.dump(self.recent_settings, f)
        except:
            pass
    
    def load_recent_settings(self):
        """최근 사용 설정 불러오기"""
        try:
            with open('recent_settings.json', 'r', encoding='utf-8') as f:
                self.recent_settings = json.load(f)
        except:
            self.recent_settings = []
    
    def _format_setting_text(self, setting):
        """설정을 버튼 텍스트로 포맷"""
        parts = []
        if setting.get('auto_fix'):
            parts.append("자동수정")
        if setting.get('ink_analysis'):
            parts.append("잉크분석")
        
        if parts:
            return "최근: " + "+".join(parts)
        else:
            return "최근: 기본"
    
    def _apply_recent_setting(self, setting):
        """최근 설정 적용"""
        self.auto_fix_var.set(setting.get('auto_fix', False))
        self.ink_analysis_var.set(setting.get('ink_analysis', False))
    
    def update_watch_status(self, is_watching):
        """감시 상태 업데이트"""
        if is_watching:
            self.watch_toggle_switch.select()
        else:
            self.watch_toggle_switch.deselect()
    
    def update_quick_stats(self):
        """빠른 통계 업데이트 - 호환성을 위한 빈 메서드"""
        # 통계 카드를 제거했으므로 아무것도 하지 않음
        pass
    
    def get_selected_folder(self):
        """선택된 폴더 정보 가져오기"""
        selection = self.folder_listbox.curselection()
        if selection:
            folder_list = self.main_window.folder_watcher.get_folder_list()
            return folder_list[selection[0]]
        return None
    
    def remove_selected_folder(self):
        """선택된 폴더 제거"""
        folder_info = self.get_selected_folder()
        if not folder_info:
            messagebox.showinfo("정보", "제거할 폴더를 선택하세요.")
            return
        
        # 확인
        if messagebox.askyesno("확인", f"'{folder_info['name']}' 폴더를 제거하시겠습니까?"):
            if self.main_window.folder_watcher.remove_folder(folder_info['path']):
                self.update_folder_list()
                self.main_window.logger.log(f"감시 폴더 제거: {folder_info['name']}")